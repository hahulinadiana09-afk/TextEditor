# Text Editor Starter

A minimal Android text editor starter built with Kotlin and Jetpack Compose.

## Current prototype
- Single editable plain-text document
- Light/dark theme toggle
- Word and character counters
- No persistent save functionality yet (planned next)

## Build
The GitHub Actions workflow in `.github/workflows/build-apk.yml` builds a debug APK on GitHub-hosted Ubuntu. The repository workflow expects `TextEditorStarter.zip` at the repository root and extracts it before running Gradle.

Toolchain versions are intentionally pinned to a mutually compatible baseline:
- Android Gradle Plugin 8.9.2
- Kotlin 2.1.20
- Gradle 8.11.1
- Android compile SDK 35
- Compose BOM 2025.03.00
- Java 17

The app's package/application ID is `com.example.texteditor`.
