# Text Editor — starter project

This is the first Android project structure for our minimal text editor.

## Current milestone

- Kotlin + Jetpack Compose application skeleton
- One plain-text writing screen
- Light/dark theme toggle
- Live word and character counts
- GitHub Actions workflow that builds a debug APK in the cloud

**Saving is not implemented yet.** It is the next development milestone. Text in this starter screen is temporary and should not be treated as safely saved.

## Build approach

The project is designed for cloud builds through GitHub Actions. The Windows 7 computer is only used to keep and edit project files with Notepad++; Gradle and the Android SDK run on GitHub's hosted Linux runner.

The workflow deliberately installs Android SDK `platform-tools`, `platforms;android-36`, and `build-tools;36.0.0`. It does not request the obsolete SDK package named `tools`. AGP 9.0 provides built-in Kotlin support, so the project does not apply the old Kotlin Android plugin.

No Gradle Wrapper is included in this starter. The workflow installs Gradle 9.1.0 directly through `gradle/actions/setup-gradle` and invokes `gradle :app:assembleDebug`.

## Project layout

```text
TextEditor/
├── .github/
│   └── workflows/
│       └── build-apk.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/texteditor/MainActivity.kt
│       └── res/values/styles.xml
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```

## Versions

- Android Gradle Plugin: 9.0.1
- Gradle: 9.1.0
- Kotlin: AGP built-in Kotlin 2.2.10
- Compose compiler plugin: 2.2.10
- Compose BOM: 2026.09.00
- Compile SDK: 36; target SDK: 35
- Minimum SDK: 23
- Build JDK: 17

## Build trigger

The APK workflow runs when code is pushed to the `main` branch, or when manually started from the repository's **Actions** tab using **Build Text Editor APK** → **Run workflow**.

When it succeeds, download the `text-editor-debug-apk` artifact from that workflow run. The APK is inside that artifact ZIP.
