package com.example.diary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val DustyPink = Color(0xFFD8AEB7)
private val DeepPink = Color(0xFF9B6674)
private val Paper = Color(0xFFFFFCF7)
private val Ink = Color(0xFF51464A)
private val MutedInk = Color(0xFF8D7E82)
private val PagePink = Color(0xFFF4E5E7)
private val LinePink = Color(0xFFE8DADD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DiaryApp() }
    }
}

@Composable
private fun DiaryApp() {
    val context = LocalContext.current
    val dao = remember { DiaryDatabase.get(context).diaryDao() }
    val documents by dao.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("diary_settings", 0) }

    var selectedId by remember { mutableStateOf<Long?>(null) }
    var showManager by remember { mutableStateOf(false) }
    var initialized by remember { mutableStateOf(false) }
    var pendingRename by remember { mutableStateOf<DiaryDocument?>(null) }
    var pendingDelete by remember { mutableStateOf<DiaryDocument?>(null) }

    LaunchedEffect(documents, initialized) {
        if (!initialized) {
            val lastId = prefs.getLong("last_document_id", -1L)
            val last = if (lastId > 0) dao.getById(lastId) else null
            if (last != null) {
                selectedId = last.id
                showManager = false
            } else {
                val newId = dao.insert(DiaryDocument())
                selectedId = newId
                prefs.edit().putLong("last_document_id", newId).apply()
                showManager = false
            }
            initialized = true
        }
    }

    val selected = documents.firstOrNull { it.id == selectedId }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = DeepPink,
            onPrimary = Color.White,
            background = PagePink,
            surface = Paper,
            onSurface = Ink,
            onBackground = Ink,
            secondary = DustyPink
        )
    ) {
        if (!initialized) {
            Box(
                Modifier.fillMaxSize().background(PagePink),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator(color = DeepPink) }
        } else if (showManager || selected == null) {
            DocumentManager(
                documents = documents,
                onNew = {
                    scope.launch {
                        val id = dao.insert(DiaryDocument())
                        selectedId = id
                        prefs.edit().putLong("last_document_id", id).apply()
                        showManager = false
                    }
                },
                onOpen = { doc ->
                    selectedId = doc.id
                    prefs.edit().putLong("last_document_id", doc.id).apply()
                    showManager = false
                },
                onRename = { pendingRename = it },
                onDelete = { pendingDelete = it }
            )
        } else {
            DiaryEditor(
                document = selected,
                onDocuments = { latestContent ->
                    scope.launch {
                        dao.update(
                            selected.id, selected.title, latestContent,
                            System.currentTimeMillis(), selected.isNamed
                        )
                        showManager = true
                    }
                },
                onContentChange = { newContent ->
                    scope.launch {
                        dao.update(
                            selected.id, selected.title, newContent,
                            System.currentTimeMillis(), selected.isNamed
                        )
                    }
                },
                onSaveNamed = { title, content ->
                    scope.launch {
                        dao.update(
                            selected.id, title, content,
                            System.currentTimeMillis(), true
                        )
                    }
                }
            )
        }

        pendingRename?.let { doc ->
            var title by remember(doc.id) { mutableStateOf(doc.title.ifBlank { "Untitled" }) }
            AlertDialog(
                onDismissRequest = { pendingRename = null },
                title = { Text("Rename document") },
                text = {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        singleLine = true,
                        label = { Text("Document name") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val cleaned = title.trim()
                        if (cleaned.isNotEmpty()) {
                            scope.launch {
                                dao.update(
                                    doc.id, cleaned, doc.content,
                                    System.currentTimeMillis(), true
                                )
                            }
                        }
                        pendingRename = null
                    }) { Text("Save") }
                },
                dismissButton = {
                    TextButton(onClick = { pendingRename = null }) { Text("Cancel") }
                }
            )
        }

        pendingDelete?.let { doc ->
            AlertDialog(
                onDismissRequest = { pendingDelete = null },
                title = { Text("Delete document?") },
                text = { Text("“${doc.title.ifBlank { "Untitled draft" }}” will be permanently deleted from this device.") },
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch {
                            dao.delete(doc.id)
                            if (selectedId == doc.id) {
                                selectedId = null
                                showManager = true
                            }
                        }
                        pendingDelete = null
                    }) { Text("Delete", color = DeepPink) }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDelete = null }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun DocumentManager(
    documents: List<DiaryDocument>,
    onNew: () -> Unit,
    onOpen: (DiaryDocument) -> Unit,
    onRename: (DiaryDocument) -> Unit,
    onDelete: (DiaryDocument) -> Unit
) {
    Column(
        Modifier.fillMaxSize().background(PagePink).safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text(
            "My Diary",
            fontSize = 30.sp,
            fontFamily = FontFamily.Serif,
            color = Ink,
            fontWeight = FontWeight.Normal
        )
        Spacer(Modifier.height(4.dp))
        Text("Your documents", color = MutedInk, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onNew,
            colors = ButtonDefaults.buttonColors(containerColor = DeepPink),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("+  New document", modifier = Modifier.padding(vertical = 4.dp))
        }
        Spacer(Modifier.height(16.dp))
        if (documents.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No documents yet.\nCreate your first page above.", color = MutedInk)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(documents, key = { it.id }) { doc ->
                    Surface(
                        color = Paper,
                        shape = RoundedCornerShape(14.dp),
                        shadowElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(doc) }
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                doc.title.ifBlank { "Untitled draft" },
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Medium,
                                color = Ink
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                doc.content.lineSequence().firstOrNull()?.take(72)
                                    ?.ifBlank { "No text yet" } ?: "No text yet",
                                color = MutedInk,
                                fontSize = 13.sp,
                                maxLines = 1
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { onRename(doc) }) { Text("Rename") }
                                TextButton(onClick = { onDelete(doc) }) {
                                    Text("Delete", color = DeepPink)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiaryEditor(
    document: DiaryDocument,
    onDocuments: (String) -> Unit,
    onContentChange: (String) -> Unit,
    onSaveNamed: (String, String) -> Unit
) {
    var text by remember(document.id) { mutableStateOf(document.content) }
    var title by remember(document.id) {
        mutableStateOf(document.title.ifBlank { "My Diary" })
    }
    var showTitleDialog by remember(document.id) { mutableStateOf(false) }
    var proposedTitle by remember(document.id) { mutableStateOf("") }
    var saveStatus by remember(document.id) { mutableStateOf("Saved") }

    LaunchedEffect(document.id, text, document.title) {
        saveStatus = "Saving…"
        delay(650)
        onContentChange(text)
        saveStatus = "Saved"
    }

    Column(
        Modifier.fillMaxSize().background(PagePink).safeDrawingPadding()
            .imePadding()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = { onDocuments(text) }) { Text("‹  Documents") }
            Text(
                "My Diary",
                fontSize = 23.sp,
                fontFamily = FontFamily.Serif,
                color = Ink
            )
            TextButton(onClick = {
                if (!document.isNamed) {
                    proposedTitle = ""
                    showTitleDialog = true
                } else {
                    onSaveNamed(document.title, text)
                    saveStatus = "Saved"
                }
            }) { Text("Save", color = DeepPink, fontWeight = FontWeight.SemiBold) }
        }

        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth().weight(1f)
                .background(Paper, RoundedCornerShape(8.dp))
                .padding(horizontal = 18.dp, vertical = 16.dp)
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val gap = 30.dp.toPx()
                var y = gap
                while (y < size.height) {
                    drawLine(
                        color = LinePink,
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1.dp.toPx()
                    )
                    y += gap
                }
            }
            BasicTextField(
                value = text,
                onValueChange = {
                    text = it
                    onContentChange(it)
                },
                modifier = Modifier.fillMaxSize(),
                textStyle = TextStyle(
                    color = Ink,
                    fontSize = 17.sp,
                    lineHeight = 30.sp
                ),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(DeepPink),
                decorationBox = { innerTextField ->
                    Box {
                        if (text.isEmpty()) {
                            Text(
                                "Start writing…",
                                color = MutedInk,
                                fontSize = 17.sp
                            )
                        }
                        innerTextField()
                    }
                }
            )
        }
        Spacer(Modifier.height(7.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("${text.trim().split(Regex("\\s+")).count { it.isNotBlank() }} words", color = MutedInk, fontSize = 12.sp)
            Text(saveStatus, color = MutedInk, fontSize = 12.sp)
        }
    }

    if (showTitleDialog) {
        AlertDialog(
            onDismissRequest = { showTitleDialog = false },
            title = { Text("Name this document") },
            text = {
                OutlinedTextField(
                    value = proposedTitle,
                    onValueChange = { proposedTitle = it },
                    singleLine = true,
                    placeholder = { Text("A little title…") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val clean = proposedTitle.trim()
                    if (clean.isNotEmpty()) {
                        title = clean
                        onSaveNamed(clean, text)
                        showTitleDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showTitleDialog = false }) { Text("Cancel") }
            }
        )
    }
}
